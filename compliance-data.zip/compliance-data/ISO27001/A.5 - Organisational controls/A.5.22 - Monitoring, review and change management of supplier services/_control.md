# A.5.22 - Monitoring, review and change management of supplier services

- **Framework:** ISO/IEC 27001 2022
- **Category:** A.5 - Organisational controls
- **Control ID:** A.5.22
- **Owner:** _unassigned_
- **Review cadence:** annual
- **Next review:** _set in app_

## Objective
Monitor and review supplier service delivery.

## Evidence checklist
- [ ] Approved policy in `policies/`
- [ ] Documented procedure in `procedures/`
- [ ] Current evidence in `evidence/`
- [ ] Completed forms/records in `forms/`

> Objective text above is a short paraphrase, not the normative standard text. Add licensed source text if your org holds it.
