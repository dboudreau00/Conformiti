# A.6.6 - Confidentiality or non-disclosure agreements

- **Framework:** ISO/IEC 27001 2022
- **Category:** A.6 - People controls
- **Control ID:** A.6.6
- **Owner:** _unassigned_
- **Review cadence:** annual
- **Next review:** _set in app_

## Objective
Use NDAs reflecting information protection needs.

## Evidence checklist
- [ ] Approved policy in `policies/`
- [ ] Documented procedure in `procedures/`
- [ ] Current evidence in `evidence/`
- [ ] Completed forms/records in `forms/`

> Objective text above is a short paraphrase, not the normative standard text. Add licensed source text if your org holds it.
