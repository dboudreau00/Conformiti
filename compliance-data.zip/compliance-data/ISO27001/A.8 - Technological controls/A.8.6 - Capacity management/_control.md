# A.8.6 - Capacity management

- **Framework:** ISO/IEC 27001 2022
- **Category:** A.8 - Technological controls
- **Control ID:** A.8.6
- **Owner:** _unassigned_
- **Review cadence:** annual
- **Next review:** _set in app_

## Objective
Monitor and tune resource use to meet capacity needs.

## Evidence checklist
- [ ] Approved policy in `policies/`
- [ ] Documented procedure in `procedures/`
- [ ] Current evidence in `evidence/`
- [ ] Completed forms/records in `forms/`

> Objective text above is a short paraphrase, not the normative standard text. Add licensed source text if your org holds it.
